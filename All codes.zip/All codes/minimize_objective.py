#!/usr/bin/env python2
# -*- coding: utf-8 -*-

'''
Name: Xiaolong Liu

Date : 2023-11-10

A module with three functions:
    init_options()
    factorize_with_mod()
    minimize()
'''

import numpy as np
import scipy as sp
import scipy.linalg


def init_options():
    '''
    Option initialization for the gradient descent algorithm

    Initialize algorithm options with default values

    Return values:
        options:
            This is a dictionary with fields that correspond to algorithmic
            options of our method.  In particular:

            max_iter:
                Maximum number of iterations
            tol:
                Convergence tolerance
            step_type:
                Different ways to calculate the search direction:
                    'gradient_descent'
                    'Newton'
            linesearch:
                Type of line search:
                    'constant'
                    'backtracking'
            alpha_init:
                First trial step size to attempt during line search:
                    'constant': Value of the constant step size
                    'backtracking': Initial trial step size
            suff_decrease_factor:
                coefficient in sufficient decrease condition for backtracking
                line search
            linesearch_tol:
                linesearch tolerance
            perturb_init:
                initial perturbation of Hessian matrix to ensure positive
                definiteness
            perturb_inc_factor:
                increase factor for Hessian perturbation
            output_level:
                Amount of output to be printed:
                    0 : No output
                    1 : Only summary information
                    2 : One line per iteration (good for debugging)
                    3 : Print iterates in each iteration
    '''
    options = {}
    options['max_iter'] = 1000
    options['tol'] = 1e-8
    options['step_type'] = 'Newton'
    options['linesearch'] = 'backtracking'
    options['alpha_init'] = 1
    options['suff_decrease_factor'] = 1e-4
    options['linesearch_tol'] = 1e-6
    options['perturb_init'] = 1e-4
    options['perturb_inc_factor'] = 10
    options['output_level'] = 1

    return options


def factorize_with_mod(hessian, perturb_init, perturb_inc_factor):
    '''
    This is an implementation of the Cholesky factorization for a
    hessian matrix

    Input arguments:
        hessian:
            A hessian matrix of objective function
        perturb_init:
            initial perturbation of Hessian matrix to ensure positive
            definiteness
        perturb_inc_factor:
            increase factor for Hessian perturbation

    Return values:
        L:
            A lower triangular matrix which is Cholesky factor
    '''
    H = hessian
    lamb = 0
    iter = 0
    while True:
        iter += 1
        try:
            L = sp.linalg.cholesky(H, lower=True)
            return L, lamb
        except sp.linalg.LinAlgError:
            if iter == 1:
                lamb = perturb_init
            else:
                lamb *= perturb_inc_factor
            H += lamb * np.eye(H.shape[0])


def minimize(opt_prob, options, x_start=None):
    '''
    Optimization methods for unconstrainted optimization

    This is an implementation of the gradient descent method for unconstrained
    optimization.

    Input arguments:
        opt_prob:
            Optimization problem object to define an unconstrained optimization
            problem.  It must have the following methods:

            val = value(x)
                returns value of objective function at x
            grad = gradient(x)
                returns gradient of objective function at x
            x_start = starting_point()
                returns a default starting point
        options:
            This is a structure with options for the algorithm.
            For details see the init_options function.
        x_start:
            Starting point.  If set to None, obtain default starting point
            from opt_problem.

    Return values:
        status:
            Return code indicating reason for termination:
            'success': Critical point found (convergence tolerance satisfied)
            'iteration limit':  Maximum number of iterations exceeded
            'error': something went wrong
        x_sol:
            Approximate critical point (or last iterate if there is a failure)
        f_sol:
            function value of x_sol
        f_record:
            record f_k in each iteration
        grad_norm_record:
            record norm of gradient in each iteration
    '''

    # Get option values
    max_iter = options['max_iter']
    tol = options['tol']
    step_type = options['step_type']
    linesearch_option = options['linesearch']
    alpha_init = options['alpha_init']
    eta = options['suff_decrease_factor']
    linesearch_tol = options['linesearch_tol']
    perturb_init = options['perturb_init']
    perturb_inc_factor = options['perturb_inc_factor']
    output_level = options['output_level']

    # return flag
    # set to error so that status has to be set explicitly in method
    status = 'error'

    # get starting point. If none is provided explicitly for this call,
    # ask the OptProblem object for it.
    if x_start is None:
        x_start = opt_prob.starting_point()
    x_k = np.copy(x_start)

    # Initialize algorithm quantities
    # iteration counter
    iter_count = 0
    func_count_total = 0
    grad_count_total = 0
    hessian_count_total = 0

    # current function value (for output), gradient, and gradient norm
    f_k = opt_prob.value(x_k)
    grad_k = opt_prob.gradient(x_k)
    norm_grad = np.linalg.norm(grad_k, np.inf)

    # This flag can be set to zero to terminate the iteration loop early
    keep_going = True


    # build record
    f_record = [f_k]
    grad_norm_record = [norm_grad]

    # Print header and zero-th iteration for output
    if output_level >= 2:
        # Print header for output
        # (This is just a fancy way to create a string.  The '%s' formating
        # makes it easy to align the header with the actual output.)
        output_header = '%6s %23s %9s %9s %9s %9s %9s %9s %9s' % \
            ('iter', 'f', '||d_k||', 'alpha', '# func', '# grad', '# hessian',
             'pertub', '||grad||')
        print(output_header)
        # If we use gradient_descent, there's no need to use hessian, so
        # there's no lambda for factorization
        if step_type == 'gradient_descent':
            lamb = np.nan
        else:
            lamb = 0
        print('%6i %23.16e %9.2e %9.2e %9i %9i %9i %9.2e %9.2e' %
              (iter_count, f_k, 0, 0, 0, 0, 0, lamb, norm_grad))
    if output_level >= 3:
        print('Current iterate:', x_k)

    ###########################
    # Main Loop
    ###########################
    while keep_going:
        # Initialize the counter for numbers of evaluation of
        # objective function, gradient and hessian in this iteration
        func_count = 0
        grad_count = 0
        hessian_count = 0

        # Check termination
        if iter_count >= max_iter:
            # Set flag to indicate the maximum number of iterations has been
            # exceeded
            status = 'iteration limit'
            break

        # Compute the search direction
        if step_type == 'Newton':
            hessian = opt_prob.hessian(x_k)
            hessian_count += 1
            # Use Cholesky factorization to convert hessian to a P.D. matrix
            # and achieve fast computation
            L, lamb = factorize_with_mod(hessian, perturb_init,
                                         perturb_inc_factor)
            v = sp.linalg.solve_triangular(L, -grad_k, lower=True)
            direction = sp.linalg.solve_triangular(L.T, v, lower=False)
        else:
            direction = -grad_k

        # Compute new iterate
        alpha_k = alpha_init
        if linesearch_option == 'constant':
            x_k = x_k + alpha_k * direction
        else:
            # Doing backtracking linesearch
            f_k_new = opt_prob.value(x_k + alpha_k * direction)
            func_count += 1
            while f_k_new > f_k + alpha_k*eta*grad_k.dot(direction):
                alpha_k /= 2
                # If alpha_k is too small, then we stop take half
                if alpha_k < linesearch_tol:
                    break
                f_k_new = opt_prob.value(x_k + alpha_k * direction)
                func_count += 1
            x_k += alpha_k * direction
            f_k = f_k_new

        # Function value and gradient
        if linesearch_option == 'constant':
            f_k = opt_prob.value(x_k)
            func_count += 1
        grad_k = opt_prob.gradient(x_k)
        grad_count += 1
        norm_grad = np.linalg.norm(grad_k, np.inf)

        # Increment iteration counter
        iter_count += 1

        # Count the total evaluation of objective functions, gradient and
        # hessian
        func_count_total += func_count
        grad_count_total += grad_count
        hessian_count_total += hessian_count

        # record the result
        f_record.append(f_k)
        grad_norm_record.append(norm_grad)

        # Iteration output
        if output_level >= 2:
            # Print the output header every 10 iterations
            if step_type == 'gradient_descent':
                if iter_count % 100 == 0:
                    print(output_header)
            else:
                if iter_count % 10 == 0:
                    print(output_header)
            d_k_norm = np.linalg.norm(direction, np.inf)
            # If we use gradient_descent, there's no need to use hessian, so
            # there's no lambda for factorization
            if step_type == 'gradient_descent':
                lamb = np.nan
            if step_type == 'gradient_descent':
                if iter_count % 100 == 0:
                    print('%6i %23.16e %9.2e %9.2e %9i %9i %9i %9.2e %9.2e' %
                          (iter_count, f_k, d_k_norm, alpha_k, func_count,
                           grad_count, hessian_count, lamb, norm_grad))
            else:
                print('%6i %23.16e %9.2e %9.2e %9i %9i %9i %9.2e %9.2e'
                      % (iter_count, f_k, d_k_norm, alpha_k, func_count,
                         grad_count, hessian_count, lamb, norm_grad))
        if output_level >= 3:
            print('Current iterate:', x_k)

        # Check if convergence tolerance satisfied
        if norm_grad <= tol:
            status = 'success'
            keep_going = False

    # Finalize results
    x_sol = np.copy(x_k)
    f_sol = f_k

    # Final output message
    if options['output_level'] >= 1:
        print('')
        print('Number of iterations............: %d' % iter_count)
        print('Total number of objective functions evaluation............: %d'
              % func_count_total)
        print('Total number of gradient evaluation............: %d'
              % grad_count_total)
        print('Total number of hessian evaluation............: %d'
              % hessian_count_total)
        print('Final objective.................: %g' % f_sol)
        print('||grad|| at final point.........: %g' % norm_grad)
        if status == 'success':
            print('Status: Critical point found.')
        elif status == 'iteration limit':
            print('Status: Maximum number of iterations (%d) exceeded.' %
                  iter_count)
        else:
            raise Exception('status has unexpected value: %s' % status)

    # Return output arguments
    return status, x_sol, f_sol, f_record, grad_norm_record
