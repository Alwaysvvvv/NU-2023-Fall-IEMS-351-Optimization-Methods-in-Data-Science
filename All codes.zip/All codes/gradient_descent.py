#!/usr/bin/env python2
# -*- coding: utf-8 -*-

'''
Python software for IEMS 351 project at Northwestern University

Copyright 2023 by Xiaolong Liu & Kedong Chen

This module provides a number of function and classes used to implement
gradient descent and stochastic gradient descent
'''

import numpy as np


def init_options():
    '''
    Option initialization for the gradient descent algorithm

    Initialize algorithm options with default values

    Return values:
        options:
            This is a dictionary with fields that correspond to algorithmic
            options of our method.  In particular:

            max_iter:
                Maximum number of iterations
            tol:
                convergence tolerance. The algorithm should stop if
                ∥∇f (x)∥∞ ≤ tol. (Default value: 10e-6.)
            output level:
                0 : No output
                1 : Only summary information
                2 : One line per iteration (good for debugging)
                3 : Print iterates in each iteration
            step size:
                step size alpha in the gradient descent algorithm
            test:
                0: Do not calculate MSE on test data
                1: Calculate MSE on test data
            print:
                0: No additional output
                1: Output the essential data for the future printing
    '''
    options = {}
    options['max_iter'] = 1000
    options['tol'] = 1e-6
    options['output_level'] = 1
    options['step_size'] = 0.1
    options['test'] = 0
    options['print'] = 0
    return options


def minimize(opt_prob, options, trainloader, testloader, x_start=None):
    '''
    Optimization methods for unconstrainted optimization

    This is an implementation of the gradient descent method for unconstrained
    optimization.

    Input arguments:
        opt_prob:
            Optimization problem object to define an unconstrained optimization
            problem.  It must have the following methods:

            val = value(x)
                returns value of objective function at x
            grad = gradient(x)
                returns gradient of objective function at x
            x_start = starting_point()
                returns a default starting point
        options:
            This is a structure with options for the algorithm.
            For details see the init_options function.
        trainloader:
            Object for iterating through the training data
        testloader:
            Object for iterating through the test data
        x_start:
            Starting point.  If set to None, obtain default starting point
            from opt_problem.

    Return values:
        status:
            Return code indicating reason for termination:
            'success': Critical point found (convergence tolerance satisfied)
            'iteration limit':  Maximum number of iterations exceeded
            'error': something went wrong
        x_sol:
            Approximate critical point (or last iterate if there is a failure)
        f_sol:
            function value of x_sol
    '''

    # Get option values
    max_iter = options['max_iter']
    step_size = options['step_size']
    output_level = options['output_level']
    test_option = options['test']
    print_info = options['print']

    # return flag
    # set to error so that status has to be set explicitly in method
    status = 'error'

    # get starting point. If none is provided explicitly for this call,
    # ask the OptProblem object for it.
    if x_start is None:
        x_start = opt_prob.starting_point()
    x_k = np.copy(x_start)

    # Initialize algorithm quantities
    # iteration counter
    iter_count = 0

    # current function value (for output), gradient, and gradient norm
    f_k = opt_prob.value(x_k, trainloader[1].numpy())
    grad_k = opt_prob.gradient(x_k, trainloader[1].numpy())
    norm_grad = np.linalg.norm(grad_k, np.inf)
    if test_option == 1:
        f_test = opt_prob.value(x_k, testloader[1].numpy())

    # This flag can be set to zero to terminate the iteration loop early
    keep_going = True

    # Print header and zero-th iteration for output
    if output_level >= 1:
        print(f"Running gradient descent method with step size\
              {options['step_size']}")
    if output_level >= 2:
        # Print header for output
        # (This is just a fancy way to create a string.  The '%s' formating
        # makes it easy to align the header with the actual output.)
        if test_option == 1:
            output_header = '%6s %23s %23s %9s' % \
                ('iter', 'f', 'f_test', '||grad||')
            print(output_header)
            print('%6i %23.16e %23.16e %9.2e' %
                  (iter_count, f_k, f_test, norm_grad))
        else:
            output_header = '%6s %23s %9s' % \
                ('iter', 'f', '||grad||')
            print(output_header)
            print('%6i %23.16e %9.2e' %
                  (iter_count, f_k, norm_grad))
    if output_level >= 3:
        print('Current iterate:', x_k)

    # Initialize a dictionary to record the print infomation
    if print_info:
        record = {}
        record['loss_epoch'] = []
        record['loss_batch'] = []
        record['norm_grad_batch'] = []
    ###########################
    # Main Loop
    ###########################
    while keep_going:
        # Check termination
        if iter_count >= max_iter:
            # Set flag to indicate the maximum number of iterations has been
            # exceeded
            status = 'iteration limit'
            break
        # check convergence, if grad smaller than tolerance, that means
        # we found the critical point!
        elif norm_grad <= options['tol']:
            status = 'success'
            break

        # This loop goes over the data set once, returning batches of data
        for i, data in enumerate(trainloader[0], 0):
            # Function value and gradient based on current batch
            grad_k = opt_prob.gradient(x_k, data.numpy())
            if print_info:
                f_k = opt_prob.value(x_k, trainloader[1].numpy())
                record['loss_batch'].append(f_k)
                norm_grad = np.linalg.norm(grad_k, np.inf)
                record['norm_grad_batch'].append(norm_grad)
            # Compute new iterate
            x_k = x_k - (step_size * grad_k)

        # Increment iteration counter
        iter_count += 1

        if print_info:
            f_k = opt_prob.value(x_k, trainloader[1].numpy())
            record['loss_epoch'].append(f_k)

        # Calculate the gradient and norm of gradient based on total data
        grad_total = opt_prob.gradient(x_k, trainloader[1].numpy())
        norm_grad = np.linalg.norm(grad_total, np.inf)
        # Iteration output
        if output_level >= 2:
            # Print the output header every 10 iterations
            if iter_count % 10 == 0:
                print(output_header)
            # Calculate the objective function based on total data
            f_k = opt_prob.value(x_k, trainloader[1].numpy())
            if test_option == 1:
                f_test = opt_prob.value(x_k, testloader[1].numpy())
                print('%6i %23.16e %23.16e %9.2e' %
                      (iter_count, f_k, f_test, norm_grad))
            else:
                print('%6i %23.16e %9.2e' %
                      (iter_count, f_k, norm_grad))
        if output_level >= 3:
            print('Current iterate:', x_k)

    # Finalize results based on total data
    x_sol = np.copy(x_k)
    f_sol = opt_prob.value(x_sol, trainloader[1].numpy())
    grad_k_total = opt_prob.gradient(x_sol, trainloader[1].numpy())
    norm_grad = np.linalg.norm(grad_k_total, np.inf)

    # Final output message
    if output_level >= 1:
        print('')
        print('Number of iterations............: %d' % iter_count)
        print('Final objective.................: %g' % f_sol)
        print('||grad|| at final point.........: %g' % norm_grad)
        if test_option == 1:
            f_test = opt_prob.value(x_sol, testloader[1].numpy())
            print('The loss on the test dataset is.........: %g' % f_test)
        if status == 'success':
            print('Status: Critical point found.')
        elif status == 'iteration limit':
            print('Status: Maximum number of iterations (%d) exceeded.' %
                  iter_count)
        else:
            raise Exception('status has unexpected value: %s' % status)

    # Return output arguments
    if print_info:
        return status, x_sol, f_sol, record
    else:
        return status, x_sol, f_sol


# class OptProblem:
#     '''
#     Base class for an unconstrained optimzation problem.

#     An instance of this class defines an unconstrained optimization problem.
#     The class must have methods for evaluating the value of the objective
#     function, its gradient, and a starting point.

#     An optimization method also needs a starting point.  It is usually part
#     of the optimization problem, so an instance of this class should also
#     provide a default starting point.  In this way, all information needed to
#     solve an optimization problem is available from this class.  The starting
#     point can also be used to find out the dimension of the optimization
#     variable.

#     In the following, n denotes the number of optimization variables
#     '''
#     def __init__(self):
#         # nothing to be done in base blass constructor
#         pass

#     def value(self, x):
#         '''
#         Compute value of the objective function at point x

#         Input arguments:
#             x: n-dim array with vector of input variables

#         Return values:
#             val: scalar value of objective function at x
#         '''
#         raise Exception('Method "value" is not implemented')

#     def gradient(self, x):
#         '''
#         Compute gradient of objective function at point x

#         Input arguments:
#             x: n-dim array with vector of input variables

#         Return values:
#             grad: n-dim array with gradient of objective function at x
#         '''

#         raise Exception('Method "gradient" is not implemented')

#     def starting_point(self):
#         '''
#         Provide a default starting point

#         Return value:
#             x_start: n-dim array with default starting point
#         '''
#         raise Exception('method "starting_point" not implemented')
